// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  readwise: {},
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
function storageSet(area, items) {
  return new Promise((resolve, reject) => {
    area.set(items, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
function storageGet(area, keys) {
  return new Promise((resolve, reject) => {
    area.get(keys, (items) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(items);
    });
  });
}
function mergeSettings(stored) {
  return {
    ...DEFAULT_SETTINGS,
    ...stored || {},
    llm: { ...DEFAULT_SETTINGS.llm, ...stored?.llm || {} },
    pinboard: { ...DEFAULT_SETTINGS.pinboard, ...stored?.pinboard || {} },
    readwise: { ...DEFAULT_SETTINGS.readwise, ...stored?.readwise || {} },
    tagging: { ...DEFAULT_SETTINGS.tagging, ...stored?.tagging || {} },
    privacy: { ...DEFAULT_SETTINGS.privacy, ...stored?.privacy || {} },
    advanced: { ...DEFAULT_SETTINGS.advanced, ...stored?.advanced || {} }
  };
}
async function getSettings() {
  const { settings } = await storageGet(chrome.storage.sync, "settings");
  return mergeSettings(settings);
}
async function getSecret(key) {
  if (!key) return void 0;
  const res = await storageGet(chrome.storage.local, key);
  return res[key];
}
async function upsertItem(item) {
  const key = `item:${item.id}`;
  await storageSet(chrome.storage.local, { [key]: item });
}
async function updateTags(map) {
  await storageSet(chrome.storage.local, { tags: map });
}
async function getTags() {
  const { tags } = await storageGet(chrome.storage.local, "tags");
  return tags || {};
}

// src/common/preview.ts
function chatCompletionsUrl(baseUrl) {
  const normalized = baseUrl.trim().replace(/\/+$/, "");
  if (!normalized) throw new Error("LLM base URL is empty");
  if (/\/chat\/completions$/i.test(normalized)) return normalized;
  return `${normalized}/chat/completions`;
}
function privacyModeLabel(mode) {
  switch (mode) {
    case "title_only":
      return "Title only";
    case "title_excerpt":
      return "Title + excerpt";
    case "full_truncated":
      return "Readable text, truncated";
  }
}
function selectExcerpt(text, mode, maxChars) {
  if (!text || mode === "title_only") return void 0;
  const limit = mode === "title_excerpt" ? Math.min(800, maxChars) : maxChars;
  return text.slice(0, Math.max(0, limit));
}
function buildLlmPayloadPreview(input, settings) {
  const excerpt = selectExcerpt(input.text, settings.privacy.mode, settings.llm.maxChars);
  const fields = [
    { key: "title", label: "Page title", value: input.title, charCount: input.title.length },
    { key: "url", label: "Page URL", value: input.url, charCount: input.url.length },
    { key: "domain", label: "Domain", value: input.domain, charCount: input.domain.length },
    {
      key: "knownTags",
      label: "Known tag context",
      value: input.knownTags.length ? `${input.knownTags.length} known tags` : "No known tags",
      charCount: input.knownTags.join(", ").length
    }
  ];
  if (excerpt !== void 0) {
    fields.push({
      key: "excerpt",
      label: settings.privacy.mode === "title_excerpt" ? "Excerpt" : "Readable text",
      value: excerpt,
      charCount: excerpt.length,
      expandable: true
    });
  }
  let endpoint;
  try {
    endpoint = chatCompletionsUrl(settings.llm.baseUrl);
  } catch {
    endpoint = void 0;
  }
  return {
    endpoint,
    privacyMode: settings.privacy.mode,
    fields,
    doesNotSend: [
      "LLM API key",
      "Pinboard token",
      "Readwise token",
      "full browser history"
    ]
  };
}
function buildDestinationPreviews(settings, state) {
  const llmEndpoint = (() => {
    try {
      return chatCompletionsUrl(settings.llm.baseUrl);
    } catch {
      return void 0;
    }
  })();
  const exportTargets = state.exportTargets || {};
  return [
    {
      id: "llm",
      label: "LLM endpoint",
      status: llmEndpoint ? "active" : "not_configured",
      statusText: llmEndpoint ? `Configured: ${llmEndpoint}` : "Not configured. No LLM payload will be sent.",
      receives: llmEndpoint ? ["page title", "page URL", "domain", "known tag context", privacyModeLabel(settings.privacy.mode)] : []
    },
    {
      id: "pinboard",
      label: "Pinboard",
      status: state.pinboardConfigured ? "active" : "not_configured",
      statusText: state.pinboardConfigured ? "Token configured. Save may sync bookmarks to Pinboard." : "Not configured. Pinboard will not receive data.",
      receives: state.pinboardConfigured ? ["page URL", "title", "tags", "short excerpt", "shared/toread flags"] : []
    },
    {
      id: "readwise",
      label: "Readwise Reader",
      status: exportTargets.readwise ? state.readwiseConfigured ? "active" : "not_configured" : "disabled",
      statusText: exportTargets.readwise ? state.readwiseConfigured ? "Selected for export." : "Selected but token is not configured." : "Not selected. Readwise will not receive data.",
      receives: exportTargets.readwise && state.readwiseConfigured ? ["page URL", "title", "tags", "source"] : []
    },
    {
      id: "goodlinks",
      label: "GoodLinks",
      status: exportTargets.goodlinks ? "active" : "disabled",
      statusText: exportTargets.goodlinks ? "Selected for export." : "Not selected. GoodLinks will not receive data.",
      receives: exportTargets.goodlinks ? ["page URL", "title", "tags"] : []
    }
  ];
}
function buildDataPreview(input, settings, state) {
  return {
    llm: buildLlmPayloadPreview(input, settings),
    destinations: buildDestinationPreviews(settings, state)
  };
}

// src/background/tabs.ts
async function extractFromActiveTab(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["readability.js"] });
  } catch {
  }
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      const url = location.href;
      const title = document.title || "";
      const domain = location.hostname;
      const hasReadability = typeof window.Readability !== "undefined";
      let text = "";
      try {
        if (hasReadability) {
          const article = new window.Readability(document.cloneNode(true)).parse();
          text = article?.textContent || "";
        }
      } catch {
      }
      if (!text) text = document.body?.innerText?.trim() || "";
      return { url, title, domain, text };
    }
  });
  return result;
}

// src/background/llm.ts
function extractErrorDetail(raw) {
  if (!raw) return void 0;
  try {
    const parsed = JSON.parse(raw);
    return parsed?.error?.message || parsed?.detail || parsed?.message;
  } catch {
    return raw.trim();
  }
}
async function generateTags(ctx) {
  const settings = await getSettings();
  const key = settings.llm.apiKeyRef ? await getSecret(settings.llm.apiKeyRef) : void 0;
  const system = 'You tag bookmarks. Prefer existing tags from the provided list; avoid near-duplicates. Output strict JSON {"tags":[{"name":"lowercase-slug","confidence":0-1}]}.';
  const contentParts = [
    `Title: ${ctx.title}`,
    `URL: ${ctx.url}`,
    `Domain: ${ctx.domain}`,
    ctx.excerpt ? `Excerpt: ${ctx.excerpt.slice(0, settings.llm.maxChars)}` : void 0,
    `Known tags: ${ctx.knownTags.join(", ")}`
  ].filter(Boolean);
  const user = contentParts.join("\n");
  const body = {
    model: settings.llm.model,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ],
    temperature: 0.2
  };
  if (settings.llm.jsonMode) body.response_format = { type: "json_object" };
  const url = chatCompletionsUrl(settings.llm.baseUrl);
  let res;
  try {
    res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...key ? { Authorization: `Bearer ${key}` } : {}
      },
      body: JSON.stringify(body)
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    throw new Error(`LLM request failed: ${message}. Verify the LLM host permission and network access.`);
  }
  if (!res.ok) {
    const detail = extractErrorDetail(await res.text());
    const msg = detail ? `: ${detail}` : "";
    throw new Error(`LLM error ${res.status}${msg}`);
  }
  let data;
  try {
    data = await res.json();
  } catch {
    throw new Error("LLM returned a non-JSON response");
  }
  const content = data?.choices?.[0]?.message?.content;
  const text = typeof content === "string" ? content : Array.isArray(content) ? content.map((part) => typeof part?.text === "string" ? part.text : "").join("") : "";
  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    const m = text.match(/\{[\s\S]*\}/);
    if (m) {
      try {
        parsed = JSON.parse(m[0]);
      } catch {
      }
    }
  }
  if (!parsed || !Array.isArray(parsed.tags)) return [];
  const tags = parsed.tags.map((t) => String(t.name || "").toLowerCase()).filter(Boolean);
  return Array.from(new Set(tags));
}

// src/background/tags.ts
function slugify(s) {
  return s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s-_]/g, "").replace(/[\s_]+/g, "-").replace(/-+/g, "-").replace(/^-|-$|\s+/g, "");
}
function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
  return dp[m][n];
}
function similarity(a, b) {
  const s1 = slugify(a), s2 = slugify(b);
  const maxLen = Math.max(s1.length, s2.length) || 1;
  const dist = levenshtein(s1, s2);
  return Math.round(100 * (1 - dist / maxLen));
}
function canonicalizeTags(candidates, known, settings) {
  const out = [];
  const knownSet = new Set(known);
  for (const t of candidates.map(slugify)) {
    const aliasTo = settings.tagging.aliases[t];
    if (aliasTo) {
      if (!out.includes(aliasTo)) out.push(aliasTo);
      continue;
    }
    if (knownSet.has(t)) {
      if (!out.includes(t)) out.push(t);
      continue;
    }
    let best = { tag: t, score: 0 };
    for (const k of knownSet) {
      const score = similarity(t, k);
      if (score > best.score) best = { tag: k, score };
    }
    if (best.score >= settings.tagging.dedupeThreshold) {
      if (!out.includes(best.tag)) out.push(best.tag);
    } else {
      if (!out.includes(t)) out.push(t);
    }
  }
  return out;
}

// src/background/pinboard.ts
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function addToPinboard(item) {
  const settings = await getSettings();
  const token = settings.pinboard.authTokenRef ? await getSecret(settings.pinboard.authTokenRef) : void 0;
  if (!token) throw new Error("Pinboard token not set");
  const params = new URLSearchParams({
    url: item.url,
    description: item.title || item.url,
    extended: (item.excerpt || "").slice(0, 250),
    tags: item.tags.join(" "),
    shared: settings.pinboard.shared ? "yes" : "no",
    toread: settings.pinboard.toread ? "yes" : "no",
    auth_token: token,
    format: "json"
  });
  let attempt = 0;
  while (attempt < 3) {
    const res = await fetch(`https://api.pinboard.in/v1/posts/add?${params.toString()}`, { method: "GET" });
    if (res.status === 429) {
      attempt++;
      await sleep(1100 * attempt);
      continue;
    }
    if (!res.ok) throw new Error(`Pinboard error ${res.status}`);
    const data = await res.json();
    if (data?.result_code && data.result_code !== "done") throw new Error(`Pinboard: ${data.result_code}`);
    return;
  }
  throw new Error("Pinboard rate limited");
}
async function importTagsFromPinboard() {
  const settings = await getSettings();
  const token = settings.pinboard.authTokenRef ? await getSecret(settings.pinboard.authTokenRef) : void 0;
  if (!token) throw new Error("Pinboard token not set");
  const url = `https://api.pinboard.in/v1/tags/get?auth_token=${encodeURIComponent(token)}&format=json`;
  const res = await fetch(url, { method: "GET" });
  if (!res.ok) throw new Error(`Pinboard error ${res.status}`);
  const data = await res.json();
  const existing = await getTags();
  let count = 0;
  for (const [tag, c] of Object.entries(data)) {
    const slug = tag.toLowerCase();
    const prev = existing[slug] || { slug, count: 0 };
    existing[slug] = { ...prev, count: (prev.count || 0) + (c || 0) };
    count += 1;
  }
  await updateTags(existing);
  return count;
}
async function listRecentFromPinboard(count = 50) {
  const settings = await getSettings();
  const token = settings.pinboard.authTokenRef ? await getSecret(settings.pinboard.authTokenRef) : void 0;
  if (!token) throw new Error("Pinboard token not set");
  const url = `https://api.pinboard.in/v1/posts/recent?auth_token=${encodeURIComponent(token)}&format=json&count=${Math.max(1, Math.min(100, count))}`;
  const res = await fetch(url, { method: "GET" });
  if (!res.ok) throw new Error(`Pinboard error ${res.status}`);
  const data = await res.json();
  const posts = Array.isArray(data?.posts) ? data.posts : [];
  return posts.map((p) => ({
    url: String(p?.href || ""),
    title: String(p?.description || p?.href || ""),
    tags: String(p?.tags || "").split(/\s+/).map((t) => t.trim().toLowerCase()).filter(Boolean)
  })).filter((p) => !!p.url);
}

// src/background/pipeline.ts
function uuid() {
  return crypto.getRandomValues(new Uint8Array(16)).reduce((p, c, i) => p + (i === 6 ? c & 15 | 64 : i === 8 ? c & 63 | 128 : c).toString(16).padStart(2, "0"), "");
}
async function tagAndMaybeSync(input) {
  const settings = await getSettings();
  const knownMap = await getTags();
  const known = Object.keys(knownMap).sort((a, b) => (knownMap[b]?.count || 0) - (knownMap[a]?.count || 0)).slice(0, settings.tagging.knownTagLimit);
  const excerpt = selectExcerpt(input.text, settings.privacy.mode, settings.llm.maxChars);
  const llmTags = await generateTags({ title: input.title, url: input.url, domain: input.domain, excerpt, knownTags: known });
  const tags = canonicalizeTags(llmTags, known, settings).map(slugify);
  for (const t of tags) {
    knownMap[t] = knownMap[t] || { slug: t, count: 0 };
    knownMap[t].count += 1;
  }
  await updateTags(knownMap);
  const item = {
    id: uuid(),
    url: input.url,
    domain: input.domain,
    title: input.title,
    excerpt,
    createdAt: Date.now(),
    tags,
    status: "tagged"
  };
  await upsertItem(item);
  try {
    await addToPinboard(item);
    item.status = "synced";
    await upsertItem(item);
  } catch {
  }
  return item;
}

// src/background/exporters.ts
async function exportToGoodlinks(items) {
  let count = 0;
  for (const it of items) {
    try {
      const url = new URL("goodlinks://add");
      url.searchParams.set("url", it.url);
      if (it.title) url.searchParams.set("title", it.title);
      if (it.tags?.length) url.searchParams.set("tags", it.tags.join(","));
      await chrome.tabs.create({ url: url.toString(), active: false });
      count += 1;
      await new Promise((r) => setTimeout(r, 150));
    } catch (e) {
      console.warn("Goodlinks export failed for", it.url, e);
    }
  }
  return count;
}
async function exportToReadwise(items) {
  const settings = await getSettings();
  const token = settings.readwise?.apiTokenRef ? await getSecret(settings.readwise.apiTokenRef) : void 0;
  if (!token) throw new Error("Readwise token not set");
  let count = 0;
  for (const it of items) {
    try {
      const res = await fetch("https://readwise.io/api/reader_api/v3/save", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Token ${token}`
        },
        body: JSON.stringify({
          url: it.url,
          title: it.title || void 0,
          tags: it.tags || [],
          source: "tldr"
        })
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      count += 1;
      await new Promise((r) => setTimeout(r, 120));
    } catch (e) {
      console.warn("Readwise export failed for", it.url, e);
    }
  }
  return count;
}

// src/background/index.ts
function settingsWithPreviewDraft(settings, draft) {
  if (!draft) return settings;
  return {
    ...settings,
    llm: {
      ...settings.llm,
      baseUrl: draft.llmBaseUrl ?? settings.llm.baseUrl,
      model: draft.llmModel ?? settings.llm.model,
      maxChars: Number.isFinite(draft.llmMaxChars) ? Number(draft.llmMaxChars) : settings.llm.maxChars
    },
    privacy: {
      ...settings.privacy,
      mode: draft.privacyMode ?? settings.privacy.mode
    }
  };
}
function knownTagNames(map, limit) {
  return Object.keys(map).sort((a, b) => (map[b]?.count || 0) - (map[a]?.count || 0)).slice(0, limit);
}
async function previewCurrentTab(draft) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) throw new Error("No active tab");
  const [data, settings, knownMap] = await Promise.all([
    extractFromActiveTab(tab.id),
    getSettings(),
    getTags()
  ]);
  const previewSettings = settingsWithPreviewDraft(settings, draft);
  const state = {
    pinboardConfigured: draft?.pinboardConfigured ?? Boolean(settings.pinboard.authTokenRef),
    readwiseConfigured: draft?.readwiseConfigured ?? Boolean(settings.readwise?.apiTokenRef),
    exportTargets: draft?.exportTargets
  };
  return buildDataPreview(
    {
      title: data.title,
      url: data.url,
      domain: data.domain,
      text: data.text,
      knownTags: knownTagNames(knownMap, previewSettings.tagging.knownTagLimit)
    },
    previewSettings,
    state
  );
}
chrome.runtime.onInstalled.addListener(async () => {
  try {
    await importTagsFromPinboard();
  } catch {
  }
  try {
    chrome.contextMenus.create({ id: "open-options", title: "Open settings", contexts: ["action"] });
  } catch {
  }
});
chrome.action.onClicked.addListener(async (tab) => {
  try {
    if (!tab?.id) throw new Error("No active tab");
    await chrome.action.setBadgeBackgroundColor({ color: "#2b7" });
    await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2026" });
    const data = await extractFromActiveTab(tab.id);
    await tagAndMaybeSync(data);
    await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2713" });
    setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2e3);
  } catch (e) {
    if (tab?.id) {
      await chrome.action.setBadgeBackgroundColor({ color: "#c33" });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
      setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2500);
    }
    console.error("Save error", e);
  }
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "open-options") {
    chrome.runtime.openOptionsPage();
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.type === "save-current-tab") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("No active tab");
      const data = await extractFromActiveTab(tab.id);
      const res = await tagAndMaybeSync(data);
      sendResponse({ ok: true, item: res });
    } else if (msg?.type === "preview-current-tab") {
      const preview = await previewCurrentTab(msg.preview);
      sendResponse({ ok: true, preview });
    } else if (msg?.type === "import-pinboard-tags") {
      const n = await importTagsFromPinboard();
      sendResponse({ ok: true, count: n });
    } else if (msg?.type === "list-pinboard-posts") {
      const count = Math.max(1, Math.min(100, Number(msg.count) || 50));
      const items = await listRecentFromPinboard(count);
      sendResponse({ ok: true, items });
    } else if (msg?.type === "export-selected") {
      const items = Array.isArray(msg.items) ? msg.items : [];
      const targets = msg.targets || {};
      let goodlinksCount = 0;
      let readwiseCount = 0;
      if (targets.goodlinks) goodlinksCount = await exportToGoodlinks(items);
      if (targets.readwise) readwiseCount = await exportToReadwise(items);
      sendResponse({ ok: true, goodlinksCount, readwiseCount });
    }
  })().catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true;
});
//# sourceMappingURL=index.js.map
