// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  readwise: {},
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings || {} };
}
async function setSettings(settings) {
  return chrome.storage.sync.set({ settings });
}
async function setSecret(key, value) {
  return chrome.storage.local.set({ [key]: value });
}

// src/ui/options.ts
function byId(id) {
  return document.getElementById(id);
}
async function load() {
  const s = await getSettings();
  byId("llm_base").value = s.llm.baseUrl;
  byId("llm_model").value = s.llm.model;
  byId("llm_json").value = String(s.llm.jsonMode);
  byId("llm_max").value = String(s.llm.maxChars);
  byId("pin_shared").value = String(s.pinboard.shared);
  byId("pin_toread").value = String(s.pinboard.toread);
  byId("tag_limit").value = String(s.tagging.knownTagLimit);
  byId("dedupe").value = String(s.tagging.dedupeThreshold);
  byId("privacy").value = s.privacy.mode;
  byId("adv").value = JSON.stringify(s.advanced || {}, null, 2);
}
async function save() {
  const newSettings = await getSettings();
  newSettings.llm.baseUrl = byId("llm_base").value.trim();
  newSettings.llm.model = byId("llm_model").value.trim();
  newSettings.llm.jsonMode = byId("llm_json").value === "true";
  newSettings.llm.maxChars = parseInt(byId("llm_max").value, 10) || 4e3;
  const llmKey = byId("llm_key").value.trim();
  if (llmKey) {
    newSettings.llm.apiKeyRef = "llm_api_key";
    await setSecret("llm_api_key", llmKey);
  }
  const pin = byId("pin_token").value.trim();
  if (pin) {
    newSettings.pinboard.authTokenRef = "pin_token";
    await setSecret("pin_token", pin);
  }
  newSettings.pinboard.shared = byId("pin_shared").value === "true";
  newSettings.pinboard.toread = byId("pin_toread").value === "true";
  const rw = byId("readwise_token")?.value?.trim();
  if (rw) {
    if (!newSettings.readwise) newSettings.readwise = {};
    newSettings.readwise.apiTokenRef = "readwise_token";
    await setSecret("readwise_token", rw);
  }
  newSettings.tagging.knownTagLimit = parseInt(byId("tag_limit").value, 10) || 200;
  newSettings.tagging.dedupeThreshold = parseInt(byId("dedupe").value, 10) || 82;
  newSettings.privacy.mode = byId("privacy").value;
  try {
    newSettings.advanced = JSON.parse(byId("adv").value || "{}");
  } catch {
  }
  await setSettings(newSettings);
  byId("status").textContent = "Saved.";
}
byId("save").addEventListener("click", save);
byId("export").addEventListener("click", async () => {
  const s = await getSettings();
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tldr-settings.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
});
byId("import").addEventListener("change", async (ev) => {
  const f = ev.target.files?.[0];
  if (!f) return;
  const text = await f.text();
  try {
    const s = JSON.parse(text);
    await setSettings(s);
    await load();
  } catch {
  }
});
load();
byId("saveCurrent").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Saving\u2026";
  chrome.permissions.request({ origins: ["<all_urls>"] }, (granted) => {
    if (!granted) {
      status.textContent = "Permission denied for page access.";
      return;
    }
    chrome.runtime.sendMessage({ type: "save-current-tab" }, (res) => {
      if (!res?.ok) {
        status.textContent = `Error: ${res?.error || "Failed"}`;
        return;
      }
      status.textContent = `Saved: ${res.item.title || res.item.url}`;
    });
  });
});
byId("importTags").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Importing tags\u2026";
  chrome.runtime.sendMessage({ type: "import-pinboard-tags" }, (res) => {
    if (!res?.ok) {
      status.textContent = `Import failed: ${res?.error || "Unknown"}`;
      return;
    }
    status.textContent = `Imported ${res.count} tags`;
  });
});
var PIN_STORAGE_KEY = "tldr.pinboard.items";
var pinItems = [];
function persistPinItems() {
  try {
    if (pinItems.length) {
      chrome.storage.local.set({ [PIN_STORAGE_KEY]: pinItems });
    } else {
      chrome.storage.local.remove(PIN_STORAGE_KEY);
    }
  } catch (err) {
    console.warn("Could not persist Pinboard items", err);
  }
}
function renderPinList() {
  const el = byId("pin_list");
  if (!el) return;
  if (!pinItems.length) {
    el.innerHTML = '<div class="status">No items loaded yet.</div>';
    return;
  }
  const rows = pinItems.map((it, i) => {
    const tags = it.tags.join(", ");
    const safeTitle = (it.title || it.url).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    const safeUrl = it.url.replace(/"/g, "&quot;");
    return `<div class="pin-item">
      <div class="checkbox-row">
        <input type="checkbox" data-idx="${i}" class="pin_sel" />
      </div>
      <div>
        <div class="pin-item-title"><a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${safeTitle}</a></div>
        <div class="pin-item-tags">${tags}</div>
      </div>
    </div>`;
  }).join("");
  el.innerHTML = rows;
}
renderPinList();
try {
  chrome.storage.local.get(PIN_STORAGE_KEY, (res) => {
    const stored = res?.[PIN_STORAGE_KEY];
    if (Array.isArray(stored) && stored.length) {
      pinItems = stored;
      renderPinList();
      const status = byId("syncStatus");
      if (status) status.textContent = `Loaded ${pinItems.length} cached item${pinItems.length === 1 ? "" : "s"}.`;
    }
  });
} catch (err) {
  console.warn("Could not hydrate Pinboard items from storage", err);
}
byId("loadFromPin")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  status.textContent = "Loading\u2026";
  const count = parseInt(byId("pin_count").value || "50", 10) || 50;
  chrome.runtime.sendMessage({ type: "list-pinboard-posts", count }, (res) => {
    if (!res?.ok) {
      status.textContent = `Error: ${res?.error || "Failed"}`;
      return;
    }
    pinItems = res.items || [];
    renderPinList();
    persistPinItems();
    status.textContent = `Loaded ${pinItems.length}`;
  });
});
byId("selectAll")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = true);
});
byId("clearSelection")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = false);
});
byId("exportSelected")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  const selectedIdxs = [];
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => {
    if (cb.checked) selectedIdxs.push(parseInt(cb.dataset.idx || "0", 10));
  });
  if (!selectedIdxs.length) {
    status.textContent = "Nothing selected.";
    return;
  }
  const items = selectedIdxs.map((i) => pinItems[i]).filter(Boolean);
  const targets = {
    goodlinks: byId("target_goodlinks")?.checked || false,
    readwise: byId("target_readwise")?.checked || false
  };
  if (!targets.goodlinks && !targets.readwise) {
    status.textContent = "Choose at least one target.";
    return;
  }
  status.textContent = "Exporting\u2026";
  chrome.runtime.sendMessage({ type: "export-selected", items, targets }, (res) => {
    if (!res?.ok) {
      status.textContent = `Export failed: ${res?.error || "Unknown"}`;
      return;
    }
    const parts = [];
    if (typeof res.goodlinksCount === "number") parts.push(`Goodlinks: ${res.goodlinksCount}`);
    if (typeof res.readwiseCount === "number") parts.push(`Readwise: ${res.readwiseCount}`);
    status.textContent = `Exported ${parts.join(", ")}`;
  });
});
try {
  const versionEl = document.getElementById("appVersion");
  if (versionEl) versionEl.textContent = `v${chrome.runtime.getManifest().version}`;
} catch {
}
var tabButtons = Array.from(document.querySelectorAll(".tab-button"));
var tabPanels = Array.from(document.querySelectorAll(".tab-panel"));
tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.tab;
    if (!target) return;
    tabButtons.forEach((b) => b.classList.toggle("active", b === btn));
    tabPanels.forEach((panel) => panel.classList.toggle("active", panel.dataset.panel === target));
    try {
      chrome.storage.local.set({ "tldr.options.activeTab": target });
    } catch {
    }
  });
});
try {
  chrome.storage.local.get("tldr.options.activeTab", (res) => {
    const target = res?.["tldr.options.activeTab"];
    if (typeof target === "string") {
      const btn = tabButtons.find((b) => b.dataset.tab === target);
      if (btn) btn.click();
    }
  });
} catch (err) {
  console.warn("Could not restore active tab", err);
}
//# sourceMappingURL=options.js.map
