// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  readwise: { saveOnCapture: false },
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
function storageSet(area, items) {
  return new Promise((resolve, reject) => {
    area.set(items, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
function storageGet(area, keys) {
  return new Promise((resolve, reject) => {
    area.get(keys, (items) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve(items);
    });
  });
}
function storageRemove(area, keys) {
  return new Promise((resolve, reject) => {
    area.remove(keys, () => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      resolve();
    });
  });
}
function mergeSettings(stored) {
  return {
    ...DEFAULT_SETTINGS,
    ...stored || {},
    llm: { ...DEFAULT_SETTINGS.llm, ...stored?.llm || {} },
    pinboard: { ...DEFAULT_SETTINGS.pinboard, ...stored?.pinboard || {} },
    readwise: { ...DEFAULT_SETTINGS.readwise, ...stored?.readwise || {} },
    tagging: { ...DEFAULT_SETTINGS.tagging, ...stored?.tagging || {} },
    privacy: { ...DEFAULT_SETTINGS.privacy, ...stored?.privacy || {} },
    advanced: { ...DEFAULT_SETTINGS.advanced, ...stored?.advanced || {} }
  };
}
async function getSettings() {
  const { settings } = await storageGet(chrome.storage.sync, "settings");
  return mergeSettings(settings);
}
async function setSettings(settings) {
  await storageSet(chrome.storage.sync, { settings });
}
async function getSecret(key) {
  if (!key) return void 0;
  const res = await storageGet(chrome.storage.local, key);
  return res[key];
}
async function setSecret(key, value) {
  if (!key) return;
  if (!value) {
    await storageRemove(chrome.storage.local, key);
    return;
  }
  await storageSet(chrome.storage.local, { [key]: value });
}

// src/common/preview.ts
function chatCompletionsUrl(baseUrl) {
  const normalized = baseUrl.trim().replace(/\/+$/, "");
  if (!normalized) throw new Error("LLM base URL is empty");
  if (/\/chat\/completions$/i.test(normalized)) return normalized;
  return `${normalized}/chat/completions`;
}
function privacyModeLabel(mode) {
  switch (mode) {
    case "title_only":
      return "Title only";
    case "title_excerpt":
      return "Title + excerpt";
    case "full_truncated":
      return "Readable text, truncated";
  }
}
function privacyModeDescription(mode) {
  switch (mode) {
    case "title_only":
      return "Sends page title, URL, domain, and tag context. No page text is sent.";
    case "title_excerpt":
      return "Sends page title, URL, domain, tag context, and a short excerpt.";
    case "full_truncated":
      return "Sends page title, URL, domain, tag context, and readable page text up to the configured character limit.";
  }
}
function buildDestinationPreviews(settings, state) {
  const llmEndpoint = (() => {
    try {
      return chatCompletionsUrl(settings.llm.baseUrl);
    } catch {
      return void 0;
    }
  })();
  const exportTargets = state.exportTargets || {};
  const readwiseRequested = Boolean(state.readwiseCaptureEnabled || exportTargets.readwise);
  const readwiseReceives = state.readwiseCaptureEnabled ? ["page URL", "title", "tags", "summary or excerpt", "source"] : ["page URL", "title", "tags", "source"];
  return [
    {
      id: "llm",
      label: "LLM endpoint",
      status: llmEndpoint ? "active" : "not_configured",
      statusText: llmEndpoint ? `Configured: ${llmEndpoint}` : "Not configured. No LLM payload will be sent.",
      receives: llmEndpoint ? ["page title", "page URL", "domain", "known tag context", privacyModeLabel(settings.privacy.mode)] : []
    },
    {
      id: "pinboard",
      label: "Pinboard",
      status: state.pinboardConfigured ? "active" : "not_configured",
      statusText: state.pinboardConfigured ? "Token configured. Save may sync bookmarks to Pinboard." : "Not configured. Pinboard will not receive data.",
      receives: state.pinboardConfigured ? ["page URL", "title", "tags", "short excerpt", "shared/toread flags"] : []
    },
    {
      id: "readwise",
      label: "Readwise Reader",
      status: readwiseRequested ? state.readwiseConfigured ? "active" : "not_configured" : "disabled",
      statusText: readwiseRequested ? state.readwiseConfigured ? state.readwiseCaptureEnabled ? "Enabled for new captures." : "Selected for export." : "Requested but token is not configured." : "Not selected. Readwise will not receive data.",
      receives: readwiseRequested && state.readwiseConfigured ? readwiseReceives : []
    },
    {
      id: "goodlinks",
      label: "GoodLinks",
      status: exportTargets.goodlinks ? "active" : "disabled",
      statusText: exportTargets.goodlinks ? "Selected for export." : "Not selected. GoodLinks will not receive data.",
      receives: exportTargets.goodlinks ? ["page URL", "title", "tags"] : []
    }
  ];
}

// src/ui/options.ts
function byId(id) {
  return document.getElementById(id);
}
var SECRET_PLACEHOLDER = "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022";
var loadedSettings;
function originPattern(url) {
  try {
    const parsed = new URL(url);
    return `${parsed.origin}/*`;
  } catch {
    return null;
  }
}
function containsOriginPermission(pattern) {
  return new Promise((resolve) => {
    chrome.permissions.contains({ origins: [pattern] }, (granted) => {
      if (chrome.runtime.lastError) {
        console.warn("Could not check permissions", chrome.runtime.lastError);
        resolve(false);
        return;
      }
      resolve(Boolean(granted));
    });
  });
}
function requestOriginPermission(pattern) {
  return new Promise((resolve) => {
    chrome.permissions.request({ origins: [pattern] }, (granted) => {
      if (chrome.runtime.lastError) {
        console.warn("Permission request failed", chrome.runtime.lastError);
        resolve(false);
        return;
      }
      resolve(Boolean(granted));
    });
  });
}
function removeOriginPermission(pattern) {
  return new Promise((resolve) => {
    chrome.permissions.remove({ origins: [pattern] }, (removed) => {
      if (chrome.runtime.lastError) {
        console.warn("Could not remove permission", chrome.runtime.lastError);
        resolve(false);
        return;
      }
      resolve(Boolean(removed));
    });
  });
}
function getActiveTab() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (chrome.runtime.lastError) {
        console.warn("Could not query active tab", chrome.runtime.lastError);
        resolve(void 0);
        return;
      }
      resolve(tabs && tabs.length ? tabs[0] : void 0);
    });
  });
}
function escapeHtml(value) {
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function inputNumber(id, fallback) {
  const value = parseInt(byId(id).value, 10);
  return Number.isFinite(value) ? value : fallback;
}
function isSecretConfigured(inputId) {
  const input = byId(inputId);
  if (input.dataset.secretState === "present") return true;
  if (input.dataset.secretMasked === "true" && input.value === SECRET_PLACEHOLDER) return true;
  return false;
}
function getExportTargets() {
  return {
    goodlinks: byId("target_goodlinks")?.checked || false,
    readwise: byId("target_readwise")?.checked || false
  };
}
function draftSettingsFromForm(base) {
  return {
    ...base,
    llm: {
      ...base.llm,
      baseUrl: byId("llm_base").value.trim(),
      model: byId("llm_model").value.trim(),
      jsonMode: byId("llm_json").value === "true",
      maxChars: inputNumber("llm_max", base.llm.maxChars)
    },
    pinboard: {
      ...base.pinboard,
      shared: byId("pin_shared").value === "true",
      toread: byId("pin_toread").value === "true"
    },
    readwise: {
      ...base.readwise,
      saveOnCapture: byId("readwise_capture").checked
    },
    tagging: {
      ...base.tagging,
      knownTagLimit: inputNumber("tag_limit", base.tagging.knownTagLimit),
      dedupeThreshold: inputNumber("dedupe", base.tagging.dedupeThreshold)
    },
    privacy: {
      ...base.privacy,
      mode: byId("privacy").value
    }
  };
}
async function getDraftSettings() {
  return draftSettingsFromForm(loadedSettings || await getSettings());
}
function getPreviewDraft() {
  const base = loadedSettings;
  const fallbackMax = base?.llm.maxChars ?? 4e3;
  return {
    llmBaseUrl: byId("llm_base").value.trim(),
    llmModel: byId("llm_model").value.trim(),
    llmMaxChars: inputNumber("llm_max", fallbackMax),
    privacyMode: byId("privacy").value,
    pinboardConfigured: isSecretConfigured("pin_token"),
    readwiseConfigured: isSecretConfigured("readwise_token"),
    readwiseCaptureEnabled: byId("readwise_capture").checked,
    exportTargets: getExportTargets()
  };
}
function destinationStatusLabel(status) {
  switch (status) {
    case "active":
      return "Active";
    case "not_configured":
      return "Not configured";
    case "disabled":
      return "Disabled";
  }
}
function renderDestination(destination) {
  const receives = destination.receives.length ? destination.receives.map((item) => `<span class="mini-pill">${escapeHtml(item)}</span>`).join("") : '<span class="mini-pill">No data sent</span>';
  return `<div class="destination">
    <div class="destination-head">
      <div class="destination-title">${escapeHtml(destination.label)}</div>
      <div class="destination-status ${destination.status}">${destinationStatusLabel(destination.status)}</div>
    </div>
    <div class="destination-copy">${escapeHtml(destination.statusText)}</div>
    <div class="destination-receives">${receives}</div>
  </div>`;
}
async function renderDataPreview() {
  const settings = await getDraftSettings();
  const mode = settings.privacy.mode;
  byId("privacy_summary").innerHTML = `<strong>${escapeHtml(privacyModeLabel(mode))}</strong>: ${escapeHtml(privacyModeDescription(mode))}`;
  const destinations = buildDestinationPreviews(settings, {
    pinboardConfigured: isSecretConfigured("pin_token"),
    readwiseConfigured: isSecretConfigured("readwise_token"),
    readwiseCaptureEnabled: byId("readwise_capture").checked,
    exportTargets: getExportTargets()
  });
  byId("destination_preview").innerHTML = destinations.map(renderDestination).join("");
}
function queueDataPreviewRender() {
  renderDataPreview().catch((err) => console.warn("Could not render data preview", err));
}
function renderCurrentPreview(preview, message) {
  const el = byId("current_preview");
  if (!preview) {
    el.classList.add("empty");
    el.textContent = message || "Preview the current tab to inspect field presence and character counts. Excerpt text stays hidden until expanded.";
    return;
  }
  const fieldRows = preview.llm.fields.map((field) => {
    const count = typeof field.charCount === "number" ? `${field.charCount} chars` : "not present";
    if (field.expandable) {
      return `<div class="preview-field">
        <div class="preview-field-head">
          <div class="preview-field-label">${escapeHtml(field.label)}</div>
          <div class="preview-count">${escapeHtml(count)}</div>
        </div>
        <button type="button" class="ghost preview-toggle" data-preview-toggle>Show text</button>
        <pre class="preview-excerpt" hidden>${escapeHtml(field.value || "")}</pre>
      </div>`;
    }
    return `<div class="preview-field">
      <div class="preview-field-head">
        <div class="preview-field-label">${escapeHtml(field.label)}</div>
        <div class="preview-count">${escapeHtml(count)}</div>
      </div>
      <div class="preview-value">${escapeHtml(field.value || "Not present")}</div>
    </div>`;
  }).join("");
  el.classList.remove("empty");
  el.innerHTML = `<div class="preview-meta">
    ${preview.llm.endpoint ? `LLM endpoint: ${escapeHtml(preview.llm.endpoint)}` : "No LLM endpoint configured."}<br />
    Does not send: ${preview.llm.doesNotSend.map(escapeHtml).join(", ")}
  </div>
  <div class="preview-fields">${fieldRows}</div>`;
  el.querySelectorAll("[data-preview-toggle]").forEach((button) => {
    button.addEventListener("click", () => {
      const excerpt = button.parentElement?.querySelector(".preview-excerpt");
      if (!excerpt) return;
      const hidden = excerpt.hasAttribute("hidden");
      excerpt.toggleAttribute("hidden", !hidden);
      button.textContent = hidden ? "Hide text" : "Show text";
    });
  });
}
async function load() {
  const s = await getSettings();
  loadedSettings = s;
  byId("llm_base").value = s.llm.baseUrl;
  byId("llm_model").value = s.llm.model;
  byId("llm_json").value = String(s.llm.jsonMode);
  byId("llm_max").value = String(s.llm.maxChars);
  byId("pin_shared").value = String(s.pinboard.shared);
  byId("pin_toread").value = String(s.pinboard.toread);
  byId("readwise_capture").checked = Boolean(s.readwise?.saveOnCapture);
  byId("tag_limit").value = String(s.tagging.knownTagLimit);
  byId("dedupe").value = String(s.tagging.dedupeThreshold);
  byId("privacy").value = s.privacy.mode;
  byId("adv").value = JSON.stringify(s.advanced || {}, null, 2);
  await Promise.all([
    hydrateSecretField("llm_key", s.llm.apiKeyRef),
    hydrateSecretField("pin_token", s.pinboard.authTokenRef),
    hydrateSecretField("readwise_token", s.readwise?.apiTokenRef)
  ]);
  queueDataPreviewRender();
}
async function save() {
  const statusEl = byId("status");
  statusEl.textContent = "Saving\u2026";
  const newSettings = await getSettings();
  const prevBase = newSettings.llm.baseUrl;
  const prevPattern = originPattern(prevBase);
  const baseInput = byId("llm_base").value.trim();
  if (!baseInput) {
    statusEl.textContent = "Enter an LLM base URL (including protocol).";
    return;
  }
  const nextPattern = originPattern(baseInput);
  if (!nextPattern) {
    statusEl.textContent = "The LLM base URL must be a valid absolute URL.";
    return;
  }
  let permissionGranted = false;
  const alreadyGranted = await containsOriginPermission(nextPattern);
  if (!alreadyGranted) {
    const granted = await requestOriginPermission(nextPattern);
    if (!granted) {
      statusEl.textContent = `Permission was not granted for ${nextPattern.replace("/*", "")}.`;
      return;
    }
    permissionGranted = true;
  }
  newSettings.llm.baseUrl = baseInput;
  newSettings.llm.model = byId("llm_model").value.trim();
  newSettings.llm.jsonMode = byId("llm_json").value === "true";
  newSettings.llm.maxChars = parseInt(byId("llm_max").value, 10) || 4e3;
  newSettings.pinboard.shared = byId("pin_shared").value === "true";
  newSettings.pinboard.toread = byId("pin_toread").value === "true";
  if (!newSettings.readwise) newSettings.readwise = {};
  newSettings.readwise.saveOnCapture = byId("readwise_capture").checked;
  newSettings.tagging.knownTagLimit = parseInt(byId("tag_limit").value, 10) || 200;
  newSettings.tagging.dedupeThreshold = parseInt(byId("dedupe").value, 10) || 82;
  newSettings.privacy.mode = byId("privacy").value;
  try {
    newSettings.advanced = JSON.parse(byId("adv").value || "{}");
  } catch {
  }
  await persistSecretField({
    inputId: "llm_key",
    storageKey: "llm_api_key",
    currentRef: newSettings.llm.apiKeyRef,
    assignRef: (ref) => {
      if (ref) newSettings.llm.apiKeyRef = ref;
      else delete newSettings.llm.apiKeyRef;
    }
  });
  await persistSecretField({
    inputId: "pin_token",
    storageKey: "pin_token",
    currentRef: newSettings.pinboard.authTokenRef,
    assignRef: (ref) => {
      if (ref) newSettings.pinboard.authTokenRef = ref;
      else delete newSettings.pinboard.authTokenRef;
    }
  });
  await persistSecretField({
    inputId: "readwise_token",
    storageKey: "readwise_token",
    currentRef: newSettings.readwise?.apiTokenRef,
    assignRef: (ref) => {
      if (!newSettings.readwise) newSettings.readwise = {};
      const readwise = newSettings.readwise;
      if (ref) readwise.apiTokenRef = ref;
      else delete readwise.apiTokenRef;
    }
  });
  await setSettings(newSettings);
  loadedSettings = newSettings;
  if (prevPattern && prevPattern !== nextPattern) {
    await removeOriginPermission(prevPattern);
  }
  statusEl.textContent = permissionGranted ? "Saved. Permission granted for your LLM host." : "Saved.";
  queueDataPreviewRender();
}
byId("save").addEventListener("click", save);
byId("export").addEventListener("click", async () => {
  const s = await getSettings();
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tldr-settings.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
});
byId("import").addEventListener("change", async (ev) => {
  const f = ev.target.files?.[0];
  if (!f) return;
  const text = await f.text();
  try {
    const s = JSON.parse(text);
    await setSettings(s);
    await load();
  } catch {
  }
});
load();
byId("previewCurrent").addEventListener("click", async () => {
  const status = byId("runtimeStatus");
  status.textContent = "Previewing\u2026";
  renderCurrentPreview(void 0, "Loading current tab preview\u2026");
  const tab = await getActiveTab();
  if (!tab?.url) {
    status.textContent = "Active tab URL unavailable.";
    renderCurrentPreview(void 0);
    return;
  }
  const tabOriginPattern = originPattern(tab.url);
  if (!tabOriginPattern) {
    status.textContent = "Cannot access this tab. Try a regular http(s) page.";
    renderCurrentPreview(void 0);
    return;
  }
  const hasPermission = await containsOriginPermission(tabOriginPattern);
  if (!hasPermission) {
    const granted = await requestOriginPermission(tabOriginPattern);
    if (!granted) {
      status.textContent = "Permission denied for this site.";
      renderCurrentPreview(void 0);
      return;
    }
  }
  chrome.runtime.sendMessage({ type: "preview-current-tab", preview: getPreviewDraft() }, (res) => {
    if (chrome.runtime.lastError) {
      status.textContent = `Preview failed: ${chrome.runtime.lastError.message || "Unknown"}`;
      renderCurrentPreview(void 0);
      return;
    }
    if (!res?.ok) {
      status.textContent = `Preview failed: ${res?.error || "Unknown"}`;
      renderCurrentPreview(void 0);
      return;
    }
    renderCurrentPreview(res.preview);
    status.textContent = "Preview ready.";
  });
});
byId("saveCurrent").addEventListener("click", async () => {
  const status = byId("runtimeStatus");
  status.textContent = "Saving\u2026";
  const tab = await getActiveTab();
  if (!tab?.url) {
    status.textContent = "Active tab URL unavailable.";
    return;
  }
  const tabOriginPattern = originPattern(tab.url);
  if (!tabOriginPattern) {
    status.textContent = "Cannot access this tab. Try a regular http(s) page.";
    return;
  }
  const hasPermission = await containsOriginPermission(tabOriginPattern);
  if (!hasPermission) {
    const granted = await requestOriginPermission(tabOriginPattern);
    if (!granted) {
      status.textContent = "Permission denied for this site.";
      return;
    }
  }
  chrome.runtime.sendMessage({ type: "save-current-tab" }, (res) => {
    if (!res?.ok) {
      status.textContent = `Error: ${res?.error || "Failed"}`;
      return;
    }
    status.textContent = `Saved: ${res.item.title || res.item.url}`;
  });
});
byId("importTags").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Importing tags\u2026";
  chrome.runtime.sendMessage({ type: "import-pinboard-tags" }, (res) => {
    if (!res?.ok) {
      status.textContent = `Import failed: ${res?.error || "Unknown"}`;
      return;
    }
    status.textContent = `Imported ${res.count} tags`;
  });
});
async function persistSecretField({ inputId, storageKey, currentRef, assignRef }) {
  const input = byId(inputId);
  const masked = input.dataset.secretMasked === "true";
  const raw = input.value.trim();
  if (masked && raw === SECRET_PLACEHOLDER) {
    if (currentRef) assignRef(currentRef);
    applySecretPresence(input, true);
    return;
  }
  if (raw) {
    await setSecret(storageKey, raw);
    assignRef(storageKey);
    applySecretPresence(input, true);
  } else {
    await setSecret(storageKey, "");
    assignRef(void 0);
    applySecretPresence(input, false);
  }
  queueDataPreviewRender();
}
async function hydrateSecretField(inputId, ref) {
  const input = byId(inputId);
  rememberPlaceholder(input);
  if (!ref) {
    applySecretPresence(input, false);
    return;
  }
  const value = await getSecret(ref);
  applySecretPresence(input, Boolean(value));
}
function rememberPlaceholder(input) {
  if (!input.dataset.originalPlaceholder) {
    input.dataset.originalPlaceholder = input.placeholder || "";
  }
}
function applySecretPresence(input, hasSecret) {
  if (hasSecret) {
    input.value = SECRET_PLACEHOLDER;
    input.dataset.secretMasked = "true";
    input.dataset.secretState = "present";
    input.placeholder = "Saved secret";
  } else {
    input.value = "";
    input.dataset.secretMasked = "false";
    input.dataset.secretState = "missing";
    input.placeholder = input.dataset.originalPlaceholder || "";
  }
}
["llm_key", "pin_token", "readwise_token"].forEach((id) => {
  const input = byId(id);
  rememberPlaceholder(input);
  input.addEventListener("focus", () => {
    if (input.dataset.secretMasked === "true") {
      input.select();
    }
  });
  input.addEventListener("input", () => {
    if (input.dataset.secretMasked === "true" && input.value !== SECRET_PLACEHOLDER) {
      input.dataset.secretMasked = "false";
      input.dataset.secretState = input.value.trim() ? "pending" : "missing";
    }
    queueDataPreviewRender();
  });
  input.addEventListener("blur", () => {
    if (!input.value.trim() && input.dataset.secretState === "pending") {
      input.dataset.secretState = "missing";
    }
    queueDataPreviewRender();
  });
});
[
  "llm_base",
  "llm_model",
  "llm_json",
  "llm_max",
  "pin_shared",
  "pin_toread",
  "readwise_capture",
  "tag_limit",
  "dedupe",
  "privacy",
  "target_goodlinks",
  "target_readwise"
].forEach((id) => {
  const el = document.getElementById(id);
  el?.addEventListener("input", queueDataPreviewRender);
  el?.addEventListener("change", queueDataPreviewRender);
});
var PIN_STORAGE_KEY = "tldr.pinboard.items";
var pinItems = [];
function persistPinItems() {
  try {
    if (pinItems.length) {
      chrome.storage.local.set({ [PIN_STORAGE_KEY]: pinItems });
    } else {
      chrome.storage.local.remove(PIN_STORAGE_KEY);
    }
  } catch (err) {
    console.warn("Could not persist Pinboard items", err);
  }
}
function renderPinList() {
  const el = byId("pin_list");
  if (!el) return;
  if (!pinItems.length) {
    el.innerHTML = '<div class="status">No items loaded yet.</div>';
    return;
  }
  const rows = pinItems.map((it, i) => {
    const tags = it.tags.join(", ");
    const safeTitle = (it.title || it.url).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    const safeUrl = it.url.replace(/"/g, "&quot;");
    return `<div class="pin-item">
      <div class="checkbox-row">
        <input type="checkbox" data-idx="${i}" class="pin_sel" />
      </div>
      <div>
        <div class="pin-item-title"><a href="${safeUrl}" target="_blank" rel="noopener noreferrer">${safeTitle}</a></div>
        <div class="pin-item-tags">${tags}</div>
      </div>
    </div>`;
  }).join("");
  el.innerHTML = rows;
}
renderPinList();
try {
  chrome.storage.local.get(PIN_STORAGE_KEY, (res) => {
    const stored = res?.[PIN_STORAGE_KEY];
    if (Array.isArray(stored) && stored.length) {
      pinItems = stored;
      renderPinList();
      const status = byId("syncStatus");
      if (status) status.textContent = `Loaded ${pinItems.length} cached item${pinItems.length === 1 ? "" : "s"}.`;
    }
  });
} catch (err) {
  console.warn("Could not hydrate Pinboard items from storage", err);
}
byId("loadFromPin")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  status.textContent = "Loading\u2026";
  const count = parseInt(byId("pin_count").value || "50", 10) || 50;
  chrome.runtime.sendMessage({ type: "list-pinboard-posts", count }, (res) => {
    if (!res?.ok) {
      status.textContent = `Error: ${res?.error || "Failed"}`;
      return;
    }
    pinItems = res.items || [];
    renderPinList();
    persistPinItems();
    status.textContent = `Loaded ${pinItems.length}`;
  });
});
byId("selectAll")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = true);
});
byId("clearSelection")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = false);
});
byId("exportSelected")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  const selectedIdxs = [];
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => {
    if (cb.checked) selectedIdxs.push(parseInt(cb.dataset.idx || "0", 10));
  });
  if (!selectedIdxs.length) {
    status.textContent = "Nothing selected.";
    return;
  }
  const items = selectedIdxs.map((i) => pinItems[i]).filter(Boolean);
  const targets = {
    goodlinks: byId("target_goodlinks")?.checked || false,
    readwise: byId("target_readwise")?.checked || false
  };
  if (!targets.goodlinks && !targets.readwise) {
    status.textContent = "Choose at least one target.";
    return;
  }
  status.textContent = "Exporting\u2026";
  chrome.runtime.sendMessage({ type: "export-selected", items, targets }, (res) => {
    if (!res?.ok) {
      status.textContent = `Export failed: ${res?.error || "Unknown"}`;
      return;
    }
    const parts = [];
    if (typeof res.goodlinksCount === "number") parts.push(`Goodlinks: ${res.goodlinksCount}`);
    if (typeof res.readwiseCount === "number") parts.push(`Readwise: ${res.readwiseCount}`);
    status.textContent = `Exported ${parts.join(", ")}`;
  });
});
try {
  const versionEl = document.getElementById("appVersion");
  if (versionEl) versionEl.textContent = `v${chrome.runtime.getManifest().version}`;
} catch {
}
var tabButtons = Array.from(document.querySelectorAll(".tab-button"));
var tabPanels = Array.from(document.querySelectorAll(".tab-panel"));
tabButtons.forEach((btn) => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.tab;
    if (!target) return;
    tabButtons.forEach((b) => b.classList.toggle("active", b === btn));
    tabPanels.forEach((panel) => panel.classList.toggle("active", panel.dataset.panel === target));
    try {
      chrome.storage.local.set({ "tldr.options.activeTab": target });
    } catch {
    }
  });
});
try {
  chrome.storage.local.get("tldr.options.activeTab", (res) => {
    const target = res?.["tldr.options.activeTab"];
    if (typeof target === "string") {
      const btn = tabButtons.find((b) => b.dataset.tab === target);
      if (btn) btn.click();
    }
  });
} catch (err) {
  console.warn("Could not restore active tab", err);
}
//# sourceMappingURL=options.js.map
