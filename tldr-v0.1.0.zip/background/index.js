// src/background/tabs.ts
async function extractFromActiveTab(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["readability.js"] });
  } catch {
  }
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      const url = location.href;
      const title = document.title || "";
      const domain = location.hostname;
      const hasReadability = typeof window.Readability !== "undefined";
      let text = "";
      try {
        if (hasReadability) {
          const article = new window.Readability(document.cloneNode(true)).parse();
          text = article?.textContent || "";
        }
      } catch {
      }
      if (!text) text = document.body?.innerText?.trim() || "";
      return { url, title, domain, text };
    }
  });
  return result;
}

// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings || {} };
}
async function getSecret(key) {
  const res = await chrome.storage.local.get(key);
  return res[key];
}
async function upsertItem(item) {
  const key = `item:${item.id}`;
  await chrome.storage.local.set({ [key]: item });
}
async function updateTags(map) {
  await chrome.storage.local.set({ tags: map });
}
async function getTags() {
  const { tags } = await chrome.storage.local.get("tags");
  return tags || {};
}

// src/background/llm.ts
async function generateTags(ctx) {
  const settings = await getSettings();
  const key = settings.llm.apiKeyRef ? await getSecret(settings.llm.apiKeyRef) : void 0;
  const system = 'You tag bookmarks. Prefer existing tags from the provided list; avoid near-duplicates. Output strict JSON {"tags":[{"name":"lowercase-slug","confidence":0-1}]}.';
  const contentParts = [
    `Title: ${ctx.title}`,
    `URL: ${ctx.url}`,
    `Domain: ${ctx.domain}`,
    ctx.excerpt ? `Excerpt: ${ctx.excerpt.slice(0, settings.llm.maxChars)}` : void 0,
    `Known tags: ${ctx.knownTags.join(", ")}`
  ].filter(Boolean);
  const user = contentParts.join("\n");
  const body = {
    model: settings.llm.model,
    messages: [
      { role: "system", content: system },
      { role: "user", content: user }
    ],
    temperature: 0.2
  };
  if (settings.llm.jsonMode) body.response_format = { type: "json_object" };
  const res = await fetch(`${settings.llm.baseUrl.replace(/\/$/, "")}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...key ? { Authorization: `Bearer ${key}` } : {}
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`LLM error ${res.status}`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content || "";
  let parsed = null;
  try {
    parsed = JSON.parse(text);
  } catch {
    const m = text.match(/\{[\s\S]*\}/);
    if (m) {
      try {
        parsed = JSON.parse(m[0]);
      } catch {
      }
    }
  }
  if (!parsed || !Array.isArray(parsed.tags)) return [];
  const tags = parsed.tags.map((t) => String(t.name || "").toLowerCase()).filter(Boolean);
  return Array.from(new Set(tags));
}

// src/background/tags.ts
function slugify(s) {
  return s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9\s-_]/g, "").replace(/[\s_]+/g, "-").replace(/-+/g, "-").replace(/^-|-$|\s+/g, "");
}
function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = Math.min(
        dp[i - 1][j] + 1,
        dp[i][j - 1] + 1,
        dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)
      );
  return dp[m][n];
}
function similarity(a, b) {
  const s1 = slugify(a), s2 = slugify(b);
  const maxLen = Math.max(s1.length, s2.length) || 1;
  const dist = levenshtein(s1, s2);
  return Math.round(100 * (1 - dist / maxLen));
}
function canonicalizeTags(candidates, known, settings) {
  const out = [];
  const knownSet = new Set(known);
  for (const t of candidates.map(slugify)) {
    const aliasTo = settings.tagging.aliases[t];
    if (aliasTo) {
      if (!out.includes(aliasTo)) out.push(aliasTo);
      continue;
    }
    if (knownSet.has(t)) {
      if (!out.includes(t)) out.push(t);
      continue;
    }
    let best = { tag: t, score: 0 };
    for (const k of knownSet) {
      const score = similarity(t, k);
      if (score > best.score) best = { tag: k, score };
    }
    if (best.score >= settings.tagging.dedupeThreshold) {
      if (!out.includes(best.tag)) out.push(best.tag);
    } else {
      if (!out.includes(t)) out.push(t);
    }
  }
  return out;
}

// src/background/pinboard.ts
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
async function addToPinboard(item) {
  const settings = await getSettings();
  const token = settings.pinboard.authTokenRef ? await getSecret(settings.pinboard.authTokenRef) : void 0;
  if (!token) throw new Error("Pinboard token not set");
  const params = new URLSearchParams({
    url: item.url,
    description: item.title || item.url,
    extended: (item.excerpt || "").slice(0, 250),
    tags: item.tags.join(" "),
    shared: settings.pinboard.shared ? "yes" : "no",
    toread: settings.pinboard.toread ? "yes" : "no",
    auth_token: token,
    format: "json"
  });
  let attempt = 0;
  while (attempt < 3) {
    const res = await fetch(`https://api.pinboard.in/v1/posts/add?${params.toString()}`, { method: "GET" });
    if (res.status === 429) {
      attempt++;
      await sleep(1100 * attempt);
      continue;
    }
    if (!res.ok) throw new Error(`Pinboard error ${res.status}`);
    const data = await res.json();
    if (data?.result_code && data.result_code !== "done") throw new Error(`Pinboard: ${data.result_code}`);
    return;
  }
  throw new Error("Pinboard rate limited");
}
async function importTagsFromPinboard() {
  const settings = await getSettings();
  const token = settings.pinboard.authTokenRef ? await getSecret(settings.pinboard.authTokenRef) : void 0;
  if (!token) throw new Error("Pinboard token not set");
  const url = `https://api.pinboard.in/v1/tags/get?auth_token=${encodeURIComponent(token)}&format=json`;
  const res = await fetch(url, { method: "GET" });
  if (!res.ok) throw new Error(`Pinboard error ${res.status}`);
  const data = await res.json();
  const existing = await getTags();
  let count = 0;
  for (const [tag, c] of Object.entries(data)) {
    const slug = tag.toLowerCase();
    const prev = existing[slug] || { slug, count: 0 };
    existing[slug] = { ...prev, count: (prev.count || 0) + (c || 0) };
    count += 1;
  }
  await updateTags(existing);
  return count;
}

// src/background/pipeline.ts
function uuid() {
  return crypto.getRandomValues(new Uint8Array(16)).reduce((p, c, i) => p + (i === 6 ? c & 15 | 64 : i === 8 ? c & 63 | 128 : c).toString(16).padStart(2, "0"), "");
}
async function tagAndMaybeSync(input) {
  const settings = await getSettings();
  const knownMap = await getTags();
  const known = Object.keys(knownMap).sort((a, b) => (knownMap[b]?.count || 0) - (knownMap[a]?.count || 0)).slice(0, settings.tagging.knownTagLimit);
  let excerpt;
  if (settings.privacy.mode === "title_only") excerpt = void 0;
  else if (settings.privacy.mode === "title_excerpt") excerpt = input.text?.slice(0, Math.min(800, settings.llm.maxChars));
  else excerpt = input.text?.slice(0, settings.llm.maxChars);
  const llmTags = await generateTags({ title: input.title, url: input.url, domain: input.domain, excerpt, knownTags: known });
  const tags = canonicalizeTags(llmTags, known, settings).map(slugify);
  for (const t of tags) {
    knownMap[t] = knownMap[t] || { slug: t, count: 0 };
    knownMap[t].count += 1;
  }
  await updateTags(knownMap);
  const item = {
    id: uuid(),
    url: input.url,
    domain: input.domain,
    title: input.title,
    excerpt,
    createdAt: Date.now(),
    tags,
    status: "tagged"
  };
  await upsertItem(item);
  try {
    await addToPinboard(item);
    item.status = "synced";
    await upsertItem(item);
  } catch {
  }
  return item;
}

// src/background/index.ts
chrome.runtime.onInstalled.addListener(async () => {
  try {
    await importTagsFromPinboard();
  } catch {
  }
  try {
    chrome.contextMenus.create({ id: "open-options", title: "Open settings", contexts: ["action"] });
  } catch {
  }
});
chrome.action.onClicked.addListener(async (tab) => {
  try {
    if (!tab?.id) throw new Error("No active tab");
    await chrome.action.setBadgeBackgroundColor({ color: "#2b7" });
    await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2026" });
    const data = await extractFromActiveTab(tab.id);
    await tagAndMaybeSync(data);
    await chrome.action.setBadgeText({ tabId: tab.id, text: "\u2713" });
    setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2e3);
  } catch (e) {
    if (tab?.id) {
      await chrome.action.setBadgeBackgroundColor({ color: "#c33" });
      await chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
      setTimeout(() => chrome.action.setBadgeText({ tabId: tab.id, text: "" }), 2500);
    }
    console.error("Save error", e);
  }
});
chrome.contextMenus.onClicked.addListener((info) => {
  if (info.menuItemId === "open-options") {
    chrome.runtime.openOptionsPage();
  }
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.type === "save-current-tab") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("No active tab");
      const data = await extractFromActiveTab(tab.id);
      const res = await tagAndMaybeSync(data);
      sendResponse({ ok: true, item: res });
    } else if (msg?.type === "import-pinboard-tags") {
      const n = await importTagsFromPinboard();
      sendResponse({ ok: true, count: n });
    }
  })().catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true;
});
//# sourceMappingURL=index.js.map
