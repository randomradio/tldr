// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  readwise: {},
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings || {} };
}
async function setSettings(settings) {
  return chrome.storage.sync.set({ settings });
}
async function setSecret(key, value) {
  return chrome.storage.local.set({ [key]: value });
}

// src/ui/options.ts
function byId(id) {
  return document.getElementById(id);
}
async function load() {
  const s = await getSettings();
  byId("llm_base").value = s.llm.baseUrl;
  byId("llm_model").value = s.llm.model;
  byId("llm_json").value = String(s.llm.jsonMode);
  byId("llm_max").value = String(s.llm.maxChars);
  byId("pin_shared").value = String(s.pinboard.shared);
  byId("pin_toread").value = String(s.pinboard.toread);
  byId("tag_limit").value = String(s.tagging.knownTagLimit);
  byId("dedupe").value = String(s.tagging.dedupeThreshold);
  byId("privacy").value = s.privacy.mode;
  byId("adv").value = JSON.stringify(s.advanced || {}, null, 2);
}
async function save() {
  const newSettings = await getSettings();
  newSettings.llm.baseUrl = byId("llm_base").value.trim();
  newSettings.llm.model = byId("llm_model").value.trim();
  newSettings.llm.jsonMode = byId("llm_json").value === "true";
  newSettings.llm.maxChars = parseInt(byId("llm_max").value, 10) || 4e3;
  const llmKey = byId("llm_key").value.trim();
  if (llmKey) {
    newSettings.llm.apiKeyRef = "llm_api_key";
    await setSecret("llm_api_key", llmKey);
  }
  const pin = byId("pin_token").value.trim();
  if (pin) {
    newSettings.pinboard.authTokenRef = "pin_token";
    await setSecret("pin_token", pin);
  }
  newSettings.pinboard.shared = byId("pin_shared").value === "true";
  newSettings.pinboard.toread = byId("pin_toread").value === "true";
  const rw = byId("readwise_token")?.value?.trim();
  if (rw) {
    if (!newSettings.readwise) newSettings.readwise = {};
    newSettings.readwise.apiTokenRef = "readwise_token";
    await setSecret("readwise_token", rw);
  }
  newSettings.tagging.knownTagLimit = parseInt(byId("tag_limit").value, 10) || 200;
  newSettings.tagging.dedupeThreshold = parseInt(byId("dedupe").value, 10) || 82;
  newSettings.privacy.mode = byId("privacy").value;
  try {
    newSettings.advanced = JSON.parse(byId("adv").value || "{}");
  } catch {
  }
  await setSettings(newSettings);
  byId("status").textContent = "Saved.";
}
byId("save").addEventListener("click", save);
byId("export").addEventListener("click", async () => {
  const s = await getSettings();
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tldr-settings.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
});
byId("import").addEventListener("change", async (ev) => {
  const f = ev.target.files?.[0];
  if (!f) return;
  const text = await f.text();
  try {
    const s = JSON.parse(text);
    await setSettings(s);
    await load();
  } catch {
  }
});
load();
byId("saveCurrent").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Saving\u2026";
  chrome.permissions.request({ origins: ["<all_urls>"] }, (granted) => {
    if (!granted) {
      status.textContent = "Permission denied for page access.";
      return;
    }
    chrome.runtime.sendMessage({ type: "save-current-tab" }, (res) => {
      if (!res?.ok) {
        status.textContent = `Error: ${res?.error || "Failed"}`;
        return;
      }
      status.textContent = `Saved: ${res.item.title || res.item.url}`;
    });
  });
});
byId("importTags").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Importing tags\u2026";
  chrome.runtime.sendMessage({ type: "import-pinboard-tags" }, (res) => {
    if (!res?.ok) {
      status.textContent = `Import failed: ${res?.error || "Unknown"}`;
      return;
    }
    status.textContent = `Imported ${res.count} tags`;
  });
});
var pinItems = [];
function renderPinList() {
  const el = byId("pin_list");
  if (!el) return;
  if (!pinItems.length) {
    el.innerHTML = "<em>No items loaded.</em>";
    return;
  }
  const rows = pinItems.map((it, i) => {
    const tags = it.tags.join(", ");
    const safeTitle = (it.title || it.url).replace(/&/g, "&amp;").replace(/</g, "&lt;");
    return `<div style="display:grid; grid-template-columns: 24px 1fr; gap:8px; padding:6px 0; border-bottom:1px solid #eee;">
      <input type="checkbox" data-idx="${i}" class="pin_sel" />
      <div>
        <div><a href="${it.url}" target="_blank" rel="noopener noreferrer">${safeTitle}</a></div>
        <div style="color:#666; font-size:12px;">${tags}</div>
      </div>
    </div>`;
  }).join("");
  el.innerHTML = rows;
}
byId("loadFromPin")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  status.textContent = "Loading\u2026";
  const count = parseInt(byId("pin_count").value || "50", 10) || 50;
  chrome.runtime.sendMessage({ type: "list-pinboard-posts", count }, (res) => {
    if (!res?.ok) {
      status.textContent = `Error: ${res?.error || "Failed"}`;
      return;
    }
    pinItems = res.items || [];
    renderPinList();
    status.textContent = `Loaded ${pinItems.length}`;
  });
});
byId("selectAll")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = true);
});
byId("clearSelection")?.addEventListener("click", () => {
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => cb.checked = false);
});
byId("exportSelected")?.addEventListener("click", () => {
  const status = byId("syncStatus");
  const selectedIdxs = [];
  document.querySelectorAll("#pin_list .pin_sel").forEach((cb) => {
    if (cb.checked) selectedIdxs.push(parseInt(cb.dataset.idx || "0", 10));
  });
  if (!selectedIdxs.length) {
    status.textContent = "Nothing selected.";
    return;
  }
  const items = selectedIdxs.map((i) => pinItems[i]).filter(Boolean);
  const targets = {
    goodlinks: byId("target_goodlinks")?.checked || false,
    readwise: byId("target_readwise")?.checked || false
  };
  if (!targets.goodlinks && !targets.readwise) {
    status.textContent = "Choose at least one target.";
    return;
  }
  status.textContent = "Exporting\u2026";
  chrome.runtime.sendMessage({ type: "export-selected", items, targets }, (res) => {
    if (!res?.ok) {
      status.textContent = `Export failed: ${res?.error || "Unknown"}`;
      return;
    }
    const parts = [];
    if (typeof res.goodlinksCount === "number") parts.push(`Goodlinks: ${res.goodlinksCount}`);
    if (typeof res.readwiseCount === "number") parts.push(`Readwise: ${res.readwiseCount}`);
    status.textContent = `Exported ${parts.join(", ")}`;
  });
});
//# sourceMappingURL=options.js.map
