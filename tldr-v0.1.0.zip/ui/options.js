// src/common/storage.ts
var DEFAULT_SETTINGS = {
  llm: { baseUrl: "https://api.moonshot.cn/v1", model: "kimi-k2-0905-preview", jsonMode: false, maxChars: 4e3 },
  pinboard: { shared: true, toread: false },
  tagging: { knownTagLimit: 200, dedupeThreshold: 82, aliases: {} },
  privacy: { mode: "title_excerpt" },
  advanced: {}
};
async function getSettings() {
  const { settings } = await chrome.storage.sync.get("settings");
  return { ...DEFAULT_SETTINGS, ...settings || {} };
}
async function setSettings(settings) {
  return chrome.storage.sync.set({ settings });
}
async function setSecret(key, value) {
  return chrome.storage.local.set({ [key]: value });
}

// src/ui/options.ts
function byId(id) {
  return document.getElementById(id);
}
async function load() {
  const s = await getSettings();
  byId("llm_base").value = s.llm.baseUrl;
  byId("llm_model").value = s.llm.model;
  byId("llm_json").value = String(s.llm.jsonMode);
  byId("llm_max").value = String(s.llm.maxChars);
  byId("pin_shared").value = String(s.pinboard.shared);
  byId("pin_toread").value = String(s.pinboard.toread);
  byId("tag_limit").value = String(s.tagging.knownTagLimit);
  byId("dedupe").value = String(s.tagging.dedupeThreshold);
  byId("privacy").value = s.privacy.mode;
  byId("adv").value = JSON.stringify(s.advanced || {}, null, 2);
}
async function save() {
  const newSettings = await getSettings();
  newSettings.llm.baseUrl = byId("llm_base").value.trim();
  newSettings.llm.model = byId("llm_model").value.trim();
  newSettings.llm.jsonMode = byId("llm_json").value === "true";
  newSettings.llm.maxChars = parseInt(byId("llm_max").value, 10) || 4e3;
  const llmKey = byId("llm_key").value.trim();
  if (llmKey) {
    newSettings.llm.apiKeyRef = "llm_api_key";
    await setSecret("llm_api_key", llmKey);
  }
  const pin = byId("pin_token").value.trim();
  if (pin) {
    newSettings.pinboard.authTokenRef = "pin_token";
    await setSecret("pin_token", pin);
  }
  newSettings.pinboard.shared = byId("pin_shared").value === "true";
  newSettings.pinboard.toread = byId("pin_toread").value === "true";
  newSettings.tagging.knownTagLimit = parseInt(byId("tag_limit").value, 10) || 200;
  newSettings.tagging.dedupeThreshold = parseInt(byId("dedupe").value, 10) || 82;
  newSettings.privacy.mode = byId("privacy").value;
  try {
    newSettings.advanced = JSON.parse(byId("adv").value || "{}");
  } catch {
  }
  await setSettings(newSettings);
  byId("status").textContent = "Saved.";
}
byId("save").addEventListener("click", save);
byId("export").addEventListener("click", async () => {
  const s = await getSettings();
  const blob = new Blob([JSON.stringify(s, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "tldr-settings.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
});
byId("import").addEventListener("change", async (ev) => {
  const f = ev.target.files?.[0];
  if (!f) return;
  const text = await f.text();
  try {
    const s = JSON.parse(text);
    await setSettings(s);
    await load();
  } catch {
  }
});
load();
byId("saveCurrent").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Saving\u2026";
  chrome.permissions.request({ origins: ["<all_urls>"] }, (granted) => {
    if (!granted) {
      status.textContent = "Permission denied for page access.";
      return;
    }
    chrome.runtime.sendMessage({ type: "save-current-tab" }, (res) => {
      if (!res?.ok) {
        status.textContent = `Error: ${res?.error || "Failed"}`;
        return;
      }
      status.textContent = `Saved: ${res.item.title || res.item.url}`;
    });
  });
});
byId("importTags").addEventListener("click", () => {
  const status = byId("runtimeStatus");
  status.textContent = "Importing tags\u2026";
  chrome.runtime.sendMessage({ type: "import-pinboard-tags" }, (res) => {
    if (!res?.ok) {
      status.textContent = `Import failed: ${res?.error || "Unknown"}`;
      return;
    }
    status.textContent = `Imported ${res.count} tags`;
  });
});
//# sourceMappingURL=options.js.map
