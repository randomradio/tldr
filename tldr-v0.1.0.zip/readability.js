// Placeholder for Mozilla Readability. Replace this file with the library to enable high-quality extraction.
// If Readability is not available, the extension falls back to body.innerText.

